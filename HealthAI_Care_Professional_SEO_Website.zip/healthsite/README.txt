HEALTHAI CARE — PROFESSIONAL WEBSITE

This version is designed to be both a local hackathon project and a deployable public website.
It does NOT use an OpenAI API key and does NOT require API credits.

LOCAL RUN
1. Open this folder in VS Code.
2. Open Terminal.
3. Run: npm.cmd start
4. Open: http://localhost:3000

FILES
- index.html  -> website structure + SEO metadata + WebSite structured data
- style.css   -> professional responsive design
- app.js      -> local health-assistant demo logic (no API)
- server.mjs  -> simple local web server
- favicon.svg -> website icon
- robots.txt  -> crawler instructions
- sitemap.xml -> sitemap template

GOOGLE SEARCH / PUBLIC WEBSITE
A localhost site cannot appear in Google Search. The website must first be published at a public URL.

Recommended beginner route:
1. Create a GitHub account.
2. Create a public repository named healthai-care.
3. Upload all files from this folder.
4. Enable GitHub Pages for the repository.
5. Your public address will be similar to:
   https://YOUR-USERNAME.github.io/healthai-care/
6. Replace YOUR-DOMAIN.com in robots.txt and sitemap.xml with the actual public URL.
7. If using GitHub Pages, the sitemap URL will be:
   https://YOUR-USERNAME.github.io/healthai-care/sitemap.xml
8. Add the public website to Google Search Console and submit the sitemap.

CUSTOM DOMAIN
For a professional brand, connect a custom domain such as your chosen .com domain to the hosting provider. Update the sitemap URL and canonical URL after choosing the final domain.

IMPORTANT
Google indexing is not instant and no one can guarantee a top ranking. Search Console helps Google discover and monitor the site. Use a unique site name, clear page title, useful original content and links to the site from other places.

HEALTH SAFETY
This prototype gives general information only. It does not diagnose disease, prescribe medicines or replace qualified medical care. Emergency symptoms require urgent professional help.
