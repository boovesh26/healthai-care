const emergencyTerms = [
  "severe chest pain", "chest pain", "difficulty breathing", "can't breathe",
  "cannot breathe", "unconscious", "heavy bleeding", "stroke", "seizure"
];

const tips = {
  diet: "🥗 Nutrition tip: Build balanced meals with vegetables or fruit, whole grains, protein-rich foods and enough water. Limit excess sugar and highly processed foods.",
  exercise: "🏃 Exercise tip: Choose activities you enjoy, such as walking, cycling, stretching or body-weight exercises. Start gradually and stop if you feel unwell.",
  sleep: "😴 Sleep tip: Keep a consistent sleep schedule, reduce screen use before bed and create a calm sleep environment. Persistent sleep problems deserve professional advice.",
  hygiene: "🧼 Hygiene tip: Wash hands regularly, keep food and drinking water clean, maintain personal hygiene and avoid sharing personal items when illness may spread."
};

function hasEmergency(q) {
  const text = q.toLowerCase();
  return emergencyTerms.some(term => text.includes(term));
}

function getAnswer(question) {
  const q = question.toLowerCase();
  if (hasEmergency(q)) {
    return "🚨 POTENTIAL EMERGENCY\n\nYour message contains a possible emergency warning sign. Please seek urgent medical attention or contact your local emergency service now. This website cannot diagnose or treat emergencies.";
  }
  if (q.includes("healthy habits") || q.includes("college student") || q.includes("student")) {
    return "🌱 Healthy habits for a college student:\n\n• Keep a regular sleep schedule and aim for adequate sleep.\n• Eat balanced meals and drink enough water.\n• Include physical activity most days.\n• Take short breaks during long study or screen sessions.\n• Manage stress through relaxation, hobbies, exercise or talking to someone you trust.\n• Maintain good personal hygiene.\n\nThis is general health information, not a diagnosis or prescription.";
  }
  if (q.includes("sleep") || q.includes("tired")) {
    return "😴 Sleep guidance:\n\nTry to keep a consistent bedtime and wake time, reduce screen use before bed, keep your room comfortable and avoid large meals or caffeine close to bedtime. If sleep problems persist or affect daily life, consider speaking with a qualified healthcare professional.";
  }
  if (q.includes("diet") || q.includes("food") || q.includes("eat") || q.includes("nutrition")) {
    return "🥗 Nutrition guidance:\n\nChoose a variety of vegetables, fruits, whole grains and protein-rich foods, and drink enough water. Limit excess sugar and highly processed foods. Individual needs vary, so personalized dietary advice should come from a qualified professional.";
  }
  if (q.includes("exercise") || q.includes("workout") || q.includes("fitness")) {
    return "🏃 Exercise guidance:\n\nStart with manageable activities such as walking, cycling, stretching or simple body-weight exercises. Increase gradually and stop if you feel unwell or have concerning symptoms. A qualified professional can advise on exercise for specific health needs.";
  }
  if (q.includes("stress") || q.includes("exam") || q.includes("anxiety")) {
    return "🧘 Stress guidance:\n\nBreak large tasks into smaller steps, take short breaks, sleep adequately, stay physically active and talk to someone you trust. If stress feels overwhelming or significantly affects daily life, consider professional support.";
  }
  return "💙 General health guidance:\n\nFocus on balanced nutrition, regular physical activity, adequate sleep, hydration, hygiene and healthy ways to manage stress. If you have symptoms that concern you, are severe, or do not improve, speak with a qualified healthcare professional.\n\nHealthAI Care provides general information only. It does not diagnose diseases or prescribe medicines.";
}

function addBubble(text, who = "bot") {
  const chat = document.getElementById("chat");
  const bubble = document.createElement("div");
  bubble.className = `bubble ${who}`;
  bubble.textContent = text;
  chat.appendChild(bubble);
  chat.scrollTop = chat.scrollHeight;
  return bubble;
}

function useQuestion(question) {
  const input = document.getElementById("question");
  input.value = question;
  input.focus();
}

function askAI() {
  const input = document.getElementById("question");
  const question = input.value.trim();
  if (!question) return;
  addBubble(question, "user");
  input.value = "";
  const loading = addBubble("Preparing a safe response...", "bot");
  setTimeout(() => { loading.textContent = getAnswer(question); }, 350);
}

function emergency() {
  const result = document.getElementById("emergencyResult");
  result.textContent = "🚨 If this is happening now, seek urgent professional medical care or contact your local emergency service. Do not rely on this website for emergency treatment.";
}

function tip(topic) {
  const result = document.getElementById("tipResult");
  result.innerHTML = `<span>💡</span><span>${tips[topic] || "Choose a topic to see a health tip."}</span>`;
}

document.getElementById("question").addEventListener("keydown", event => {
  if (event.key === "Enter") askAI();
});
